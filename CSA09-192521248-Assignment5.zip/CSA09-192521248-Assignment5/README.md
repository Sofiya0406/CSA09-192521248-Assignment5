# Programming in Java – Assignment 5 (CO5)
**Name:** S. Sofiya  
**Register Number:** 192521248  
**Course:** Programming in Java  
**Topic:** Data Persistence Engineering – Files and Databases  
**Java version:** Java 17

## Repository contents
- Task01: File format design and bus-pass file operations
- Task02: Buffered I/O and line counting
- Task03: DAO design pattern
- Task04: Object serialization
- Task05: JDBC transactions and SQL injection prevention
- Task06: File-store implementation and buffering experiment
- Task07: Adversarial input testing
- Task08: Statement, PreparedStatement and batch processing
- Task09: Migration, metadata and final engineering decision

## Compile and run
Open a task folder in a terminal. Compile a standalone Java file with:
```bash
javac FileName.java
java ClassName
```
For JDBC tasks, add the MySQL Connector/J driver to the classpath and edit the database URL, username and password in the source before running.

## Evidence checklist
Add your own screenshots of each program's execution to the corresponding task folder. Run the benchmark programs on your computer and enter the measured values in the experiment tables. Do not report sample/expected values as measured results.

## GitHub submission
Create a repository named `CSA09-192521248-Assignment5`. Upload this folder structure and share the repository with the faculty (public, or private with faculty added as collaborator). Make at least one meaningful commit per task.
